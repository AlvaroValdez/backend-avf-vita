// backend/server.js
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const compression = require('compression');
const morgan = require('morgan');
const config = require('./config/env');
const connectDB = require('./config/db');

const app = express();

// Middlewares
app.use(helmet());
app.use(compression());
app.use(express.json({ limit: '1mb' }));

app.use(cors({
  origin: [config.app.frontendOrigin, 'http://localhost:5173', 'http://127.0.0.1:5173'],
  credentials: true,
}));

if (!config.app.isProd) app.use(morgan('dev'));

// Rutas
app.use('/api', require('./routes/api'));
app.use('/api/auth', require('./routes/auth')); // tu authControllerFinal ya implementado

// 404
app.use((req,res) => res.status(404).json({ message: 'Endpoint no encontrado' }));

// Error handler
app.use((err,req,res,next) => {
  console.error('💥 Uncaught error:', err);
  res.status(500).json({ message: 'Error interno' });
});

// Start
(async () => {
  try {
    await connectDB();
    app.listen(config.app.port, () => {
      console.log('==================================================');
      console.log(`🚀 Servidor escuchando en ${config.app.baseUrl}`);
      console.log(`🌍 Entorno: ${config.app.env}`);
      console.log(`🔗 Frontend: ${config.app.frontendOrigin}`);
      console.log(`🔌 API: ${config.app.baseUrl}/api`);
      console.log('==================================================');
      console.log('🔐 Vita configured?:', config.vita.isConfigured,
        '| login:', !!config.vita.login, '| apiKey:', !!config.vita.apiKey, '| secret:', !!config.vita.secret);
    });
  } catch (e) {
    console.error('❌ Error de arranque:', e);
    process.exit(1);
  }
})();
