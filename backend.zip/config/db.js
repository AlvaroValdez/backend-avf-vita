// backend/config/db.js
'use strict';

const mongoose = require('mongoose');
const { mongo, app } = require('./env');

async function connectDB() {
  if (!mongo?.uri) {
    console.warn('⚠️  MongoDB deshabilitado (sin MONGODB_URI). Continuando sin DB.');
    return; // no lanzar error; permite levantar API sin DB
  }

  mongoose.set('strictQuery', true);

  const opts = {
    dbName: mongo.dbName,
    user: mongo.user || undefined,
    pass: mongo.pass || undefined,
    maxPoolSize: mongo.maxPoolSize || 10,
    autoIndex: !app.isProd,
    serverSelectionTimeoutMS: 5000,
  };

  await mongoose.connect(mongo.uri, opts);

  const conn = mongoose.connection;
  console.log(`✅ Mongo conectado: ${conn.host}/${conn.name}`);

  conn.on('disconnected', () => console.warn('⚠️  Mongo desconectado'));
  conn.on('reconnected', () => console.log('🔄 Mongo reconectado'));
  conn.on('error', (err) => console.error('💥 Mongo error:', err.message));
}

module.exports = connectDB;
