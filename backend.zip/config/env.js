require('dotenv').config();

const bool = v => String(v).toLowerCase() === 'true';

module.exports = {
  app: {
    env: process.env.NODE_ENV || 'development',
    isProd: (process.env.NODE_ENV === 'production'),
    port: Number(process.env.PORT || 5000),
    baseUrl: process.env.BASE_URL || `http://localhost:${process.env.PORT || 5000}`,
    frontendOrigin: process.env.FRONTEND_ORIGIN || 'http://localhost:5173',
  },
  vita: {
    baseURL: process.env.VITA_BASE_URL || 'https://api.stage.vitawallet.io/api/businesses',
    login: process.env.VITA_X_LOGIN,
    apiKey: process.env.VITA_X_API_KEY,
    secret: process.env.VITA_SECRET_KEY,
    isConfigured: !!(process.env.VITA_X_LOGIN && process.env.VITA_X_API_KEY && process.env.VITA_SECRET_KEY),
    timeoutMs: 15000,
  },
  mongo: {
    uri: process.env.MONGO_URI,
  }
};
