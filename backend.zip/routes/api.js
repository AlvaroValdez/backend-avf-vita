const router = require('express').Router();
const prices = require('../controllers/pricesController');
const countries = require('../controllers/countriesController');
const rules = require('../controllers/rulesController');
const wallets = require('../controllers/walletsController');
const tx = require('../controllers/transactionsController');

router.get('/health', (_req, res) => res.json({ ok: true, ts: Date.now() }));
router.get('/prices', prices.getPrices);
router.get('/countries', countries.getCountries);
router.get('/withdrawal-rules', rules.getWithdrawalRules);
router.get('/wallets', wallets.listWallets);
router.get('/transactions', tx.listTransactions);

module.exports = router;
