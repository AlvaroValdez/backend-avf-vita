const Transaction = require('../models/Transaction');
const Wallet = require('../models/Wallet');

// Función para obtener precios
const getPrices = async (req, res) => {
    try {
        console.log('📊 Fetching prices...');
        
        // Datos mock temporales - luego puedes conectar con base de datos o API externa
        const prices = {
            CLP: {
                attributes: {
                    clp_sell: { 
                        "BO": 0.011, 
                        "CO": 4.2, 
                        "PE": 0.0037, 
                        "VE": 0.0009, 
                        "CL": 1 
                    },
                    fixed_cost: { 
                        "BO": 6.5, 
                        "CO": 4500, 
                        "PE": 5.0, 
                        "VE": 4.0, 
                        "CL": 1000 
                    },
                    business_days_of_payment: { 
                        "BO": 1, 
                        "CO": 1, 
                        "PE": 1, 
                        "VE": 1, 
                        "CL": 1 
                    },
                    valid_until: Date.now() + 1000 * 60 * 3 // 3 minutos de validez
                }
            }
        };
        
        console.log('✅ Prices fetched successfully');
        res.status(200).json(prices);
    } catch (error) {
        console.error('❌ Error fetching prices:', error);
        res.status(500).json({ 
            error: 'Internal server error',
            message: error.message 
        });
    }
};

// Crear una nueva transacción
const createTransaction = async (req, res) => {
  try {
    const {
      amount,
      currency,
      country,
      beneficiary,
      purpose,
      walletId
    } = req.body;

    // Validaciones básicas
    if (!amount || !currency || !country || !beneficiary || !walletId) {
      return res.status(400).json({ message: 'Faltan campos obligatorios' });
    }

    // Verificar que la wallet pertenece al usuario
    const wallet = await Wallet.findOne({ _id: walletId, user: req.userId });
    if (!wallet) {
      return res.status(404).json({ message: 'Wallet no encontrada' });
    }

    // Verificar saldo suficiente
    if (wallet.balance < amount) {
      return res.status(400).json({ message: 'Saldo insuficiente' });
    }
   
    // Calcular el monto que recibirá el destinatario
    const fxData = prices[currency]?.attributes;
    if (!fxData) {
      return res.status(400).json({ message: 'Moneda no soportada' });
    }
    
    const fxKey = Object.keys(fxData).find(k => k.endsWith('_sell'));
    const fxRate = fxData[fxKey][country];
    const fixedCost = fxData.fixed_cost[country];
    const businessDays = fxData.business_days_of_payment[country];
    
    const receiveAmount = (amount * fxRate) - fixedCost;
    
    if (receiveAmount <= 0) {
      return res.status(400).json({ message: 'El monto a recibir debe ser mayor a cero' });
    }

    // Preparar datos para Vita Wallet
    const transactionData = {
      url_notify: `${process.env.BASE_URL}/api/transactions/notify`,
      beneficiary_first_name: beneficiary.firstName,
      beneficiary_last_name: beneficiary.lastName,
      beneficiary_email: beneficiary.email,
      beneficiary_address: beneficiary.address,
      beneficiary_document_type: beneficiary.documentType,
      beneficiary_document_number: beneficiary.documentNumber,
      account_type_bank: beneficiary.accountType,
      account_bank: beneficiary.accountNumber,
      bank_code: beneficiary.bankCode,
      purpose: purpose.code,
      purpose_comentary: purpose.comment,
      country: country,
      currency: currency.toLowerCase(), // Vita espera lowercase
      amount: amount,
      order: `TX${Date.now()}${Math.random().toString(36).substr(2, 5)}`.toUpperCase(),
      transactions_type: 'withdrawal',
      wallet: walletId
    };

    // Actualizar saldo de la wallet
    wallet.balance -= amount;
    await wallet.save();
    
    // Guardar transacción en nuestra base de datos
    const transaction = new Transaction({
      user: req.userId,
      orderId: transactionData.order,
      amount: amount,
      currency: currency,
      receiveAmount: receiveAmount,
      receiveCurrency: getDestinationCurrency(country),
      country: country,
      status: 'pending',
      fee: fixedCost,
      fxRate: fxRate,
      businessDays: businessDays,
      beneficiary: beneficiary,
      vitaTransactionId: vitaTransaction.data?.id,
      wallet: walletId
    });
    
    await transaction.save();
    
    res.status(201).json({
      message: 'Transacción creada exitosamente',
      transaction: await Transaction.findById(transaction._id).populate('wallet', 'name currency')
    });
  } catch (error) {
    console.error('Error creando transacción:', error);
    res.status(500).json({ message: error.message });
  }
};

// Obtener historial de transacciones
const getTransactions = async (req, res) => {
  try {
    const { page = 1, limit = 10, status } = req.query;
    const userId = req.userId;
    
    const query = { user: userId };
    if (status && status !== 'all') {
      query.status = status;
    }
    
    const options = {
      page: parseInt(page),
      limit: parseInt(limit),
      sort: { createdAt: -1 },
      populate: {
        path: 'wallet',
        select: 'name currency'
      }
    };
    
    // Usar paginación si está disponible, sino usar find normal
    let transactions;
    if (Transaction.paginate) {
      transactions = await Transaction.paginate(query, options);
    } else {
      transactions = await Transaction.find(query)
        .sort(options.sort)
        .limit(options.limit * 1)
        .skip((options.page - 1) * options.limit)
        .populate(options.populate);
      
      const count = await Transaction.countDocuments(query);
      transactions = {
        docs: transactions,
        totalDocs: count,
        totalPages: Math.ceil(count / options.limit),
        page: options.page
      };
    }
    
    res.json({
      transactions: transactions.docs,
      totalPages: transactions.totalPages,
      currentPage: transactions.page,
      total: transactions.totalDocs
    });
  } catch (error) {
    console.error('Error obteniendo transacciones:', error);
    res.status(500).json({ message: 'Error al obtener transacciones' });
  }
};

// Obtener transacción por ID
const getTransactionById = async (req, res) => {
  try {
    const transaction = await Transaction.findById(req.params.id).populate('wallet', 'name currency');
    if (!transaction) {
      return res.status(404).json({ message: 'Transacción no encontrada' });
    }
    res.json(transaction);
  } catch (error) {
    console.error('Error obteniendo transacción:', error);
    res.status(500).json({ message: 'Error al obtener transacción' });
  }
};

// Webhook para notificaciones de Vita Wallet
const handleNotification = async (req, res) => {
  try {
    const { order, status } = req.body;
    
    // Buscar y actualizar la transacción
    const transaction = await Transaction.findOne({ orderId: order });
    if (transaction) {
      transaction.status = status.toLowerCase();
      await transaction.save();
      
      // Aquí podrías agregar notificaciones por email, etc.
      console.log(`Transacción ${order} actualizada a estado: ${status}`);
      
      // Si la transacción fue completada o denegada, podrías notificar al usuario
      if (status === 'completed' || status === 'denied') {
        // Lógica de notificación al usuario
      }
    }
    
    res.status(200).send('OK');
  } catch (error) {
    console.error('Error procesando notificación:', error);
    res.status(500).send('Error');
  }
};

// Función auxiliar para obtener moneda destino
function getDestinationCurrency(countryCode) {
  const currencies = {
    'BO': 'BOB',
    'CO': 'COP',
    'PE': 'PEN',
    'VE': 'VES',
    'CL': 'CLP'
  };
  return currencies[countryCode] || 'USD';
}

// Get withdrawal rules for a specific country
const getWithdrawalRules = async (req, res) => {
    try {
        const { country } = req.query;
        
        console.log('📋 Fetching withdrawal rules for country:', country);
        
        if (!country) {
            return res.status(400).json({ 
                error: 'Country parameter is required',
                example: '/api/transactions/withdrawal-rules?country=CO' 
            });
        }

        // Datos mock de reglas por país (luego puedes conectar con DB)
        const rulesByCountry = {
            'CO': [ // Colombia
                { type: "text", name: "Nombre(s)", key: "beneficiary_first_name", required: true, min: 2 },
                { type: "text", name: "Apellido(s)", key: "beneficiary_last_name", required: true, min: 2 },
                { type: "text", name: "Número de documento", key: "beneficiary_document_number", required: true, min: 6 },
                { type: "select", name: "Tipo de documento", key: "beneficiary_document_type", required: true, 
                  options: [
                    { value: "CC", label: "Cédula de Ciudadanía" },
                    { value: "CE", label: "Cédula de Extranjería" },
                    { value: "PAS", label: "Pasaporte" }
                  ] 
                },
                { type: "email", name: "Email", key: "beneficiary_email", required: false },
                { type: "text", name: "Número de cuenta", key: "account_bank", required: true, min: 10 },
                { type: "select", name: "Tipo de cuenta", key: "account_type_bank", required: true,
                  options: [
                    { value: "savings", label: "Cuenta de Ahorros" },
                    { value: "checking", label: "Cuenta Corriente" }
                  ]
                },
                { type: "select", name: "Banco", key: "bank_code", required: true,
                  options: [
                    { value: "001", label: "Bancolombia" },
                    { value: "002", label: "Banco de Bogotá" },
                    { value: "003", label: "Davivienda" },
                    { value: "004", label: "BBVA" },
                    { value: "005", label: "Banco Popular" }
                  ]
                }
            ],
            'PE': [ // Perú
                { type: "text", name: "Nombres", key: "beneficiary_first_name", required: true, min: 2 },
                { type: "text", name: "Apellidos", key: "beneficiary_last_name", required: true, min: 2 },
                { type: "text", name: "DNI", key: "beneficiary_document_number", required: true, min: 8, max: 8 },
                { type: "text", name: "Número de cuenta", key: "account_bank", required: true, min: 10 },
                { type: "select", name: "Banco", key: "bank_code", required: true,
                  options: [
                    { value: "BCP", label: "Banco de Crédito del Perú" },
                    { value: "BBVA", label: "BBVA Perú" },
                    { value: "SCOTIABANK", label: "Scotiabank Perú" },
                    { value: "INTERBANK", label: "Interbank" }
                  ]
                }
            ],
            'BO': [ // Bolivia
                { type: "text", name: "Nombres", key: "beneficiary_first_name", required: true, min: 2 },
                { type: "text", name: "Apellidos", key: "beneficiary_last_name", required: true, min: 2 },
                { type: "text", name: "CI", key: "beneficiary_document_number", required: true, min: 6 },
                { type: "text", name: "Número de cuenta", key: "account_bank", required: true, min: 10 }
            ],
            'VE': [ // Venezuela
                { type: "text", name: "Nombres", key: "beneficiary_first_name", required: true, min: 2 },
                { type: "text", name: "Apellidos", key: "beneficiary_last_name", required: true, min: 2 },
                { type: "text", name: "Cédula", key: "beneficiary_document_number", required: true, min: 6 },
                { type: "text", name: "Número de cuenta", key: "account_bank", required: true, min: 15 }
            ],
            'CL': [ // Chile
                { type: "text", name: "Nombres", key: "beneficiary_first_name", required: true, min: 2 },
                { type: "text", name: "Apellidos", key: "beneficiary_last_name", required: true, min: 2 },
                { type: "text", name: "RUT", key: "beneficiary_document_number", required: true, min: 8 },
                { type: "text", name: "Número de cuenta", key: "account_bank", required: true, min: 10 }
            ]
        };

        const rules = rulesByCountry[country] || [];
        
        if (rules.length === 0) {
            return res.status(404).json({ 
                error: 'No withdrawal rules found for country',
                country: country,
                availableCountries: Object.keys(rulesByCountry)
            });
        }

        console.log('✅ Withdrawal rules found:', rules.length, 'for country', country);
        res.status(200).json(rules);
        
    } catch (error) {
        console.error('❌ Error fetching withdrawal rules:', error);
        res.status(500).json({ 
            error: 'Internal server error',
            message: error.message 
        });
    }
};

// Exportar todas las funciones
module.exports = {
    getPrices,
    createTransaction,
    getTransactions,
    getTransactionById,
    handleNotification,
    getWithdrawalRules
};