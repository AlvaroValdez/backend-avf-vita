// backend/controllers/rulesController.js
const vita = require('../services/vitaService');

exports.getWithdrawalRules = async (req, res) => {
  try {
    const country = String(req.query.country || '').toUpperCase();
    const rules = await vita.getWithdrawalRules(country);
    return res.json(rules || []);
  } catch (e) {
    console.error('❌ rulesController.getWithdrawalRules', e.status, e.message, e.data);
    return res.status(e.status || 500).json({ message: e.message, data: e.data || null });
  }
};
