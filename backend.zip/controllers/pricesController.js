// backend/controllers/pricesController.js
const vita = require('../services/vitaService');

exports.getPrices = async (req, res) => {
  try {
    const data = await vita.getPricesDirect();
    return res.json(data);
  } catch (e) {
    console.error('❌ pricesController.getPrices', e.status, e.message, e.data);
    return res.status(e.status || 500).json({ message: e.message });
  }
};
