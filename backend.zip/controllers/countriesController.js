// backend/controllers/countriesController.js
const vita = require('../services/vitaService');

exports.getCountries = async (req, res) => {
  try {
    const countries = await vita.getAvailableCountries();
    console.log('🌎 countries →', countries);
    return res.json({ data: countries }); // siempre MAYÚSCULAS
  } catch (e) {
    console.error('❌ countriesController.getCountries', e.status, e.message, e.data);
    const status = e.status || 500;
    return res.status(status).json({ message: e.message || 'No se pudieron obtener los países' });
  }
};
