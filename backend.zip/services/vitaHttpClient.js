// services/vitaHttpClient.js
const axios = require('axios');
const crypto = require('crypto');
const config = require('../config/env');

// ---- Firma V2 (doc Vita): HMAC(secret, x-login + x-date + sorted_body) ----
// GET: sorted_body = ''  => firma sobre (x-login + x-date)
function signV2({ xLogin, xDate, secret, body }) {
  const sortedBody = body && typeof body === 'object' && Object.keys(body).length
    ? Object.keys(body).sort().map(k => `${k}${String(body[k])}`).join('')
    : '';
  const payload = `${xLogin}${xDate}${sortedBody}`;
  return crypto.createHmac('sha256', secret).update(payload).digest('hex');
}

const client = axios.create({
  baseURL: config.vita.baseURL,
  timeout: config.vita.timeoutMs,
});

// Interceptor para firmar TODO request a Vita
client.interceptors.request.use(req => {
  if (!config.vita.isConfigured) return req;

  const xDate = new Date().toISOString();
  const xLogin = config.vita.login;
  const xApiKey = config.vita.apiKey;

  // Para GET/DELETE no hay body en firma
  const body = (req.method && req.method.toUpperCase() === 'GET') ? null : (req.data || null);

  const signature = signV2({ xLogin, xDate, secret: config.vita.secret, body });

  req.headers = {
    ...(req.headers || {}),
    'Accept': 'application/json',
    'Content-Type': 'application/json',
    'x-date': xDate,
    'x-login': xLogin,
    'x-api-key': xApiKey,     // requerido pero NO entra al hash
    'Authorization': `V2-HMAC-SHA256, Signature:${signature}`,
  };

  return req;
});

module.exports = client;
