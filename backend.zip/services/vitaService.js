// services/vitaService.js
const vita = require('./vitaHttpClient');
const config = require('../config/env');

const mem = {
  prices: { at: 0, data: null },       // cache 30s
  rules:  { at: 0, byCountry: {} },    // cache 5m por país
};

const ttl = {
  prices: 30_000,
  rules:  5 * 60_000,
};

function now() { return Date.now(); }

// Normaliza países desde /prices (withdrawal o moneda raíz)
function extractCountriesFromPrices(prices) {
  // La doc indica endpoint /businesses/prices y estructura con withdrawal/vita_sent
  // y/o secciones por moneda con *_sell (ej: clp_sell) en local currency. :contentReference[oaicite:4]{index=4}
  const set = new Set();

  const addKeys = obj => {
    if (!obj) return;
    Object.keys(obj).forEach(k => set.add(k.toUpperCase()));
  };

  const attrPaths = [];

  // 1) withdrawal.prices.attributes.clp_sell / usd_sell / cop_sell...
  if (prices.withdrawal?.prices?.attributes) {
    const attrs = prices.withdrawal.prices.attributes;
    Object.keys(attrs).forEach(key => {
      if (/_sell$/i.test(key) && typeof attrs[key] === 'object') addKeys(attrs[key]);
    });
  }

  // 2) secciones por moneda: { CLP: { attributes: { clp_sell: {...} } } }
  Object.values(prices).forEach(entry => {
    const attrs = entry?.attributes;
    if (!attrs) return;
    Object.keys(attrs).forEach(key => {
      if (/_sell$/i.test(key) && typeof attrs[key] === 'object') addKeys(attrs[key]);
    });
  });

  return Array.from(set);
}

async function getPrices() {
  const age = now() - mem.prices.at;
  if (mem.prices.data && age < ttl.prices) return mem.prices.data;

  try {
    const { data } = await vita.get('/prices'); // path relativo a .../api/businesses :contentReference[oaicite:5]{index=5}
    mem.prices = { at: now(), data };
    return data;
  } catch (err) {
    console.error('❌ getPrices:', err?.response?.status, err?.message);
    // No lances error: devolvemos estructura mínima para no romper FE
    return mem.prices.data || { withdrawal: { prices: { attributes: {} } } };
  }
}

async function getAvailableCountries() {
  const prices = await getPrices();
  const countries = extractCountriesFromPrices(prices);
  return countries;
}

async function getWithdrawalRules(country) {
  // cache por país
  const hit = mem.rules.byCountry[country];
  if (hit && (now() - hit.at) < ttl.rules) return hit.data;

  try {
    // Endpoint de reglas (GET) en businesses: /withdrawal_rules :contentReference[oaicite:6]{index=6}
    const { data } = await vita.get('/withdrawal_rules', { params: { country } });
    mem.rules.byCountry[country] = { at: now(), data };
    return data;
  } catch (err) {
    console.error('❌ getWithdrawalRules:', err?.response?.status, err?.message);
    mem.rules.byCountry[country] = { at: now(), data: [] };
    return [];
  }
}

async function getWallets(page = 1, count = 20) {
  try {
    // El listado clásico está “deprecated” pero sigue documentado: /wallets?page=&count= :contentReference[oaicite:7]{index=7}
    const { data } = await vita.get('/wallets', { params: { page, count } });
    return data;
  } catch (err) {
    console.error('❌ getWallets:', err?.response?.status, err?.message);
    return { data: [], meta: { total: 0 } };
  }
}

async function getTransactions(page = 1, count = 10) {
  try {
    const { data } = await vita.get('/transactions', { params: { page, count } });
    return data;
  } catch (err) {
    console.error('❌ getTransactions:', err?.response?.status, err?.message);
    return { data: [], meta: { total: 0 } };
  }
}

module.exports = {
  getPrices,
  getAvailableCountries,
  getWithdrawalRules,
  getWallets,
  getTransactions,
};
